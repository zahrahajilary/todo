# Todo Task

### Todo test Task for digikala

##### zahra hajilary

for runnig project:
```bash
npm install
npm run build
cd dist
python3 -m http.server 8000
```
or simply double click on index.html inside dist folder